import React from "react";
import cart from "./cart.png";

export const CartWidget = () => {
  return (
    <div>
      <img src={cart} alt="cart" width="50px" />
    </div>
  );
};
